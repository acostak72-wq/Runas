import React from 'react';
import { ZodiacSign } from '../types';
import { ZODIAC_SIGNS } from '../constants';
import { motion } from 'motion/react';

interface ZodiacGridProps {
  onSelect: (sign: ZodiacSign) => void;
  selectedId?: string;
}

const ZodiacGrid: React.FC<ZodiacGridProps> = ({ onSelect, selectedId }) => {
  return (
    <section className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-20">
      {ZODIAC_SIGNS.map((sign) => (
        <motion.div
          key={sign.id}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => onSelect(sign)}
          className={`glass-card p-6 rounded-xl flex flex-col items-center text-center group transition-all duration-500 cursor-pointer ${
            selectedId === sign.id
              ? 'border-primary/40 shadow-[0_0_20px_rgba(212,175,55,0.1)]'
              : ''
          }`}
        >
          <div
            className={`w-16 h-16 mb-4 flex items-center justify-center rounded-full border transition-colors ${
              selectedId === sign.id
                ? 'border-2 border-primary/40 bg-primary/5'
                : 'border-primary/20 group-hover:border-primary/60'
            }`}
          >
            <span className={`text-3xl font-headline ${selectedId === sign.id ? 'text-primary' : 'text-primary'}`}>
              {sign.symbol}
            </span>
          </div>
          <h3
            className={`font-headline text-lg tracking-widest ${
              selectedId === sign.id ? 'text-primary' : 'text-on-surface'
            }`}
          >
            {sign.name}
          </h3>
          <p
            className={`text-xs uppercase tracking-tighter ${
              selectedId === sign.id ? 'text-primary/60' : 'text-on-surface-variant/60'
            }`}
          >
            {sign.dateRange}
          </p>
        </motion.div>
      ))}
    </section>
  );
};

export default ZodiacGrid;

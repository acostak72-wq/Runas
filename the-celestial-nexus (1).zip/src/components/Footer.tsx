import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="w-full py-12 border-t border-[#d4af37]/10 bg-[#101419] flex flex-col items-center gap-6 mt-auto">
      <div className="flex gap-8">
        <a className="font-body text-xs tracking-widest uppercase text-[#a4c9ff]/40 hover:text-[#f2ca50] transition-opacity underline" href="#">Privacy Policy</a>
        <a className="font-body text-xs tracking-widest uppercase text-[#a4c9ff]/40 hover:text-[#f2ca50] transition-opacity" href="#">Terms of Fate</a>
        <a className="font-body text-xs tracking-widest uppercase text-[#a4c9ff]/40 hover:text-[#f2ca50] transition-opacity" href="#">Contact the Seer</a>
      </div>
      <p className="font-body text-xs tracking-widest uppercase text-[#a4c9ff]/40">
        © 2024 The Celestial Nexus. Ancient Wisdom for Modern Souls.
      </p>
    </footer>
  );
};

export default Footer;

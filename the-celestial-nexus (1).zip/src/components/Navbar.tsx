import React from 'react';
import { Music, Share2 } from 'lucide-react';

const Navbar: React.FC = () => {
  return (
    <nav className="fixed top-0 w-full flex justify-between items-center px-8 py-4 bg-[#101419]/80 backdrop-blur-xl z-50 shadow-[0_10px_30px_rgba(0,0,0,0.5)] bg-gradient-to-b from-[#101419] to-transparent">
      <div className="text-2xl font-bold tracking-[0.2em] text-[#f2ca50] drop-shadow-[0_0_8px_rgba(242,202,80,0.4)] font-headline uppercase">
        The Celestial Nexus
      </div>
      <div className="hidden md:flex gap-8 items-center font-headline tracking-wider uppercase text-xs">
        <a className="text-[#f2ca50] border-b-2 border-[#f2ca50] pb-1 hover:text-[#f2ca50] hover:opacity-100 transition-all duration-300" href="#">Futhark</a>
        <a className="text-[#a4c9ff] opacity-70 hover:text-[#f2ca50] hover:opacity-100 transition-all duration-300" href="#">Zodiac</a>
        <a className="text-[#a4c9ff] opacity-70 hover:text-[#f2ca50] hover:opacity-100 transition-all duration-300" href="#">Oracles</a>
      </div>
      <div className="flex items-center gap-4 text-[#f2ca50]">
        <button className="hover:scale-105 transition-transform">
          <Music size={20} />
        </button>
        <button className="hover:scale-105 transition-transform">
          <Share2 size={20} />
        </button>
        <div className="w-8 h-8 rounded-full overflow-hidden border border-primary/30">
          <img
            alt="Guardian Avatar"
            referrerPolicy="no-referrer"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuAVxx-D_r5_BKkgX1jSR_AX_-YB4fBlQeSBUQ1zNLsSQEtEXbR-QXxBqqx8VwQ4dr0f2gAaM16l65Hy0Eex5XBc6n2BDTLUOI1JY6j4S3LM6D_tmuZvtwZgFoU4jelTlHijQO4Vna23L21rA2Iii5vuelOuqYQuUrLL9ZKFqUiNstHpcXVac3f5DywbosGvVECl_1v96Wg-eBytnqXT1C9utsH86CTJpSVFL8xIkwvcgvZfuU2v1BsVxt3c8AsGE6TNb4W79soQfqpv"
          />
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

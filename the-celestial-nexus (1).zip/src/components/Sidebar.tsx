import React from 'react';
import { Sparkles, Compass, BookOpen, Diamond } from 'lucide-react';

const Sidebar: React.FC = () => {
  const menuItems = [
    { icon: Sparkles, label: 'Daily Rune', active: true },
    { icon: Compass, label: 'Zodiac Map' },
    { icon: BookOpen, label: 'Futhark Lore' },
    { icon: Diamond, label: 'Crystal Shop' },
  ];

  return (
    <aside className="hidden lg:flex flex-col h-screen pt-24 pb-8 w-64 fixed left-0 border-r border-[#d4af37]/15 bg-[#101419] z-40">
      <div className="px-6 mb-10">
        <h2 className="font-headline text-[#f2ca50] text-xl">Ancient Nexus</h2>
        <p className="text-[#a4c9ff]/60 text-xs tracking-widest uppercase">Viking Rune Oracle</p>
      </div>
      <nav className="flex-1 flex flex-col gap-2">
        {menuItems.map((item) => (
          <a
            key={item.label}
            className={`flex items-center gap-4 px-6 py-3 transition-colors duration-500 font-light ${
              item.active
                ? 'bg-[#d4af37]/10 text-[#f2ca50] border-r-4 border-[#f2ca50]'
                : 'text-[#a4c9ff]/60 hover:bg-[#101419] hover:text-[#f2ca50]'
            }`}
            href="#"
          >
            <item.icon size={20} />
            <span>{item.label}</span>
          </a>
        ))}
      </nav>
      <div className="px-6 mt-auto">
        <button className="w-full py-3 bg-gradient-to-r from-primary to-primary-container text-on-primary rounded-full font-bold text-sm shadow-[0_0_15px_rgba(242,202,80,0.3)] hover:shadow-primary/50 transition-all">
          Get Premium Reading
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;

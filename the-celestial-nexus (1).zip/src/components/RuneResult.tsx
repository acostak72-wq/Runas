import React from 'react';
import { ZodiacSign } from '../types';
import { motion } from 'motion/react';
import { Sparkles, Compass, CreditCard, Shield, Share2, RefreshCw } from 'lucide-react';

interface RuneResultProps {
  sign: ZodiacSign;
  onReset: () => void;
}

const RuneResult: React.FC<RuneResultProps> = ({ sign, onReset }) => {
  const { rune } = sign;

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="space-y-12 mb-20"
      id="results"
    >
      <div className="relative py-12 flex flex-col md:flex-row items-center justify-center gap-12 glass-card rounded-3xl overflow-hidden border-2 border-primary/30">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent pointer-events-none" />
        
        {/* Pulsating Rune */}
        <div className="relative z-10">
          <motion.div
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 3, repeat: Infinity }}
            className="w-48 h-64 bg-surface-container-low rounded-2xl flex items-center justify-center border-2 border-primary/50 shadow-[0_0_40px_rgba(242,202,80,0.2)]"
          >
            <span className="text-9xl font-headline text-primary rune-glow leading-none">
              {rune.symbol}
            </span>
          </motion.div>
          <div className="mt-6 text-center">
            <h2 className="text-3xl font-headline text-primary tracking-widest">{rune.name}</h2>
            <p className="text-sm text-secondary tracking-widest uppercase mt-1">
              {rune.description}
            </p>
          </div>
        </div>

        {/* Rune Significance Bento Grid */}
        <div className="z-10 grid grid-cols-1 md:grid-cols-2 gap-4 flex-1 max-w-2xl">
          <div className="p-5 glass-card rounded-2xl border-primary/10">
            <div className="flex items-center gap-3 mb-2 text-primary">
              <Sparkles size={18} />
              <h4 className="font-headline text-sm tracking-widest uppercase">Significado</h4>
            </div>
            <p className="text-on-surface-variant text-sm leading-relaxed">
              {rune.meaning}
            </p>
          </div>
          <div className="p-5 glass-card rounded-2xl border-primary/10">
            <div className="flex items-center gap-3 mb-2 text-primary">
              <Compass size={18} />
              <h4 className="font-headline text-sm tracking-widest uppercase">Destino</h4>
            </div>
            <p className="text-on-surface-variant text-sm leading-relaxed">
              {rune.destiny}
            </p>
          </div>
          <div className="p-5 glass-card rounded-2xl border-primary/10">
            <div className="flex items-center gap-3 mb-2 text-primary">
              <CreditCard size={18} />
              <h4 className="font-headline text-sm tracking-widest uppercase">Finanzas</h4>
            </div>
            <p className="text-on-surface-variant text-sm leading-relaxed">
              {rune.finance}
            </p>
          </div>
          <div className="p-5 glass-card rounded-2xl border-primary/10">
            <div className="flex items-center gap-3 mb-2 text-primary">
              <Shield size={18} />
              <h4 className="font-headline text-sm tracking-widest uppercase">Amuleto</h4>
            </div>
            <p className="text-on-surface-variant text-sm leading-relaxed">
              {rune.amulet}
            </p>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-wrap justify-center gap-6">
        <button className="px-8 py-4 bg-gradient-to-r from-[#25D366] to-[#128C7E] text-white rounded-full flex items-center gap-3 shadow-lg hover:scale-105 transition-transform">
          <Share2 size={20} />
          Compartir en WhatsApp
        </button>
        <button
          onClick={onReset}
          className="px-8 py-4 border border-primary/40 text-primary rounded-full hover:bg-primary/10 transition-colors font-bold uppercase tracking-widest text-xs flex items-center gap-2"
        >
          <RefreshCw size={20} />
          Consultar otro signo
        </button>
      </div>
    </motion.section>
  );
};

export default RuneResult;

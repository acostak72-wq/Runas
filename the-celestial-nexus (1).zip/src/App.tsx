import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import ZodiacGrid from './components/ZodiacGrid';
import RuneResult from './components/RuneResult';
import Footer from './components/Footer';
import StarBackground from './components/StarBackground';
import { ZodiacSign } from './types';
import { Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [selectedSign, setSelectedSign] = useState<ZodiacSign | null>(null);

  const handleSelectSign = (sign: ZodiacSign) => {
    setSelectedSign(sign);
    // Scroll to results
    setTimeout(() => {
      const resultsElement = document.getElementById('results');
      if (resultsElement) {
        resultsElement.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  const handleReset = () => {
    setSelectedSign(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <StarBackground />
      
      {/* Background image overlay */}
      <div 
        className="fixed inset-0 opacity-20 pointer-events-none z-[-1]" 
        style={{ 
          backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuApmUxDxEGF8bMU7hh8NGsrbMXVp9ceScOtwKO4rY7aPo4jzh2bXiAdX77Y-UMGOcc0Tfl3x4py-Zst35GB2KS3GjPNz2DxKEnUnv7VfthmZiOG33tAj6DVIgWC9nuDxC-SWYCjfVrqQG_FHr2USkUKalJo8hKikpX0dOZy7VAKzoYFcvsyiPPzNn1m28ESTk_-kwPuFD9z7OLN1-_Cbho4H6aQT3cjVRbaExbl5-k2tbOGmZZRNPdILqiDr7dlJMle9pNwrUWOjEmc')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }} 
      />

      <Navbar />
      <Sidebar />

      <main className="lg:pl-64 pt-24 min-h-screen flex flex-col">
        <div className="max-w-6xl mx-auto w-full px-6 py-12 flex-1">
          
          {/* Hero Section */}
          <header className="text-center mb-16 space-y-4">
            <motion.h1 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-5xl md:text-7xl font-headline font-black text-on-surface tracking-tighter"
            >
              ORÁCULO <span className="text-primary italic">RÚNICO</span>
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-on-surface-variant max-w-2xl mx-auto text-lg leading-relaxed"
            >
              Sincroniza tu signo zodiacal con las antiguas vibraciones del Futhark. Descubre lo que los dioses han tallado para ti en el tejido del destino.
            </motion.p>
            <div className="flex justify-center gap-4 pt-4">
              <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-primary/40 my-auto" />
              <Sparkles className="text-primary" size={24} />
              <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-primary/40 my-auto" />
            </div>
          </header>

          <ZodiacGrid onSelect={handleSelectSign} selectedId={selectedSign?.id} />

          <AnimatePresence>
            {selectedSign && (
              <RuneResult sign={selectedSign} onReset={handleReset} />
            )}
          </AnimatePresence>

          {/* SEO Content Section */}
          <section className="border-t border-primary/10 pt-20 pb-12">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <h2 className="text-4xl font-headline text-on-surface tracking-tight">
                  EL PODER DEL <span className="text-primary">FUTHARK ANTIGUO</span>
                </h2>
                <div className="space-y-4 text-on-surface-variant leading-relaxed">
                  <p>
                    El Futhark antiguo es el alfabeto rúnico más antiguo, utilizado por las tribus germánicas del siglo II al VIII. Cada símbolo no es solo una letra, sino un contenedor de fuerzas cósmicas y arquetipos universales.
                  </p>
                  <p>
                    En el Celestial Nexus, unimos esta sabiduría ancestral con la astrología caldea para ofrecerte una lectura multidimensional que resuena con tu energía zodiacal específica.
                  </p>
                </div>
                <div className="flex gap-4">
                  <span className="px-4 py-2 bg-surface-container-highest rounded-full text-xs text-primary/80 uppercase tracking-widest font-bold">Mitología Nórdica</span>
                  <span className="px-4 py-2 bg-surface-container-highest rounded-full text-xs text-primary/80 uppercase tracking-widest font-bold">Astrología</span>
                  <span className="px-4 py-2 bg-surface-container-highest rounded-full text-xs text-primary/80 uppercase tracking-widest font-bold">Misticismo</span>
                </div>
              </div>
              <div className="relative group">
                <div className="absolute -inset-2 bg-primary/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition duration-1000" />
                <img
                  alt="Mystical Runes"
                  referrerPolicy="no-referrer"
                  className="relative rounded-2xl grayscale hover:grayscale-0 transition-all duration-700 shadow-2xl border border-primary/20"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuBYlqcSGjDq3q_mCmVtcmVvA7enTfX6Q5CzEcNyGrV4EraPXNQlLh9y227nWyJmnMJqLVfQ-JCredN_G8xmVue0_5y12rNQXxcjb0X9qssAOOyXjuhrQcklJzIS1wi61tt7vbW-0DJHNvCvWnmG0D51Y4SMl5t4_mS12iBM0JGkiqLXLs6eabLwSXOGQXXgtgXRJUtR_5dPvRRIJ9Zxe3LlH-6DuyWrHi6EbxpObSBQxg49Ic7Ce8P3NnPat0BUgeCHxKqJ9_vWhdCT"
                />
              </div>
            </div>
          </section>
        </div>

        <Footer />
      </main>

      {/* Floating Audio Control */}
      <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 bg-surface-container-highest/60 backdrop-blur-md p-2 rounded-full border border-primary/20">
        <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-on-primary cursor-pointer hover:scale-110 transition-transform">
          <Sparkles size={18} />
        </div>
        <div className="pr-4">
          <p className="text-[10px] uppercase tracking-widest text-primary font-bold">Ambient Channel</p>
          <p className="text-xs text-on-surface whitespace-nowrap">Echoes of Valhalla</p>
        </div>
      </div>
    </div>
  );
}

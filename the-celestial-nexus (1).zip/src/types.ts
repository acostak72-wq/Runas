export interface ZodiacSign {
  id: string;
  name: string;
  symbol: string;
  dateRange: string;
  rune: Rune;
}

export interface Rune {
  name: string;
  symbol: string;
  meaning: string;
  destiny: string;
  finance: string;
  amulet: string;
  description: string;
}
